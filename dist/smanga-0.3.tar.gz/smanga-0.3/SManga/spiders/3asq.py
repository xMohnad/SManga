from SManga.lib.themes.madara import Madara


class Al3asqSpider(Madara):
    name = "3asq"
    base_url = "https://3asq.org/"
    extract_info_from_script = True
