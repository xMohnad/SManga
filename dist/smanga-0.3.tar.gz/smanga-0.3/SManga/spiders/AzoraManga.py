from SManga.lib.themes.madara import Madara


class AzoramangaSpider(Madara):
    name = "Azora"
    base_url = "https://azoramoon.com/"
