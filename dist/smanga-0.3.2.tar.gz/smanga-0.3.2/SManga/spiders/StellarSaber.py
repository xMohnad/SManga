from SManga.lib.themes.mangathemesia import MangaThemesiaSpider


class StellarsaberSpider(MangaThemesiaSpider):
    name = "StellarSaber"
    base_url = "https://stellarsaber.pro/"
    language = "Ara"
