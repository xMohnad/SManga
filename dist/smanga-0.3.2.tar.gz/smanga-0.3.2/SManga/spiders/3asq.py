from SManga.lib.themes.madara import Madara


class Al3asqSpider(Madara):
    name = "3asq"
    base_url = "https://3asq.org/"
    language = "Ara"
    extract_details_from_script = True