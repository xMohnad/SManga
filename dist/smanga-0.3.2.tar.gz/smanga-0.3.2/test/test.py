import curses
from SManga.core.data_processor import SpiderDataProcessor

def _generate_file_name_from_url(self, url: str) -> str:
    from urllib.parse import urlparse
    return str(Path(urlparse(url).path).parent.name)

class MenuItem:
    """Represents a menu item for a manga."""

    def __init__(self, manganame="", site="", lastchapter="", json_file=""):
        self.manganame = manganame
        self.site = site
        self.lastchapter = lastchapter
        self.json_file = json_file

    @classmethod
    def load_menu_items_from_json(cls):
        """Load menu items from processed JSON data."""
        processor = SpiderDataProcessor()
        processed_data = processor.load_processed_data()

        if not processed_data:
            return []

        return [cls(**item) for item in processed_data]

    def display(self, max_width):
        """Format the display text for a menu item, truncating if necessary."""
        text = self.manganame
    
        # Remove any text within parentheses to clean up the display text
        if '(' in text and ')' in text:
            text = text[:text.rfind('(')].strip() + text[text.rfind(')') + 1:].strip()
    
        # Calculate available space after adding the site name and separator
        available_width = max_width - len(f" - {self.site}")
    
        # Truncate the text if it exceeds the available width, and append '...' if truncated
        if len(text) > available_width:
            text = text[:available_width - 3] + "..."
    
        return f"{text} - {self.site}"


class Menu:
    """Handles menu display and interactions."""

    def __init__(self, items):
        self.items = items
        self.filtered_items = sorted(items, key=lambda item: item.manganame)
        self.current_row = 0
        self.search_mode = False
        self.search_query = ""
        self.offset = 0
        self.sort_by_site = False

    def render(self, stdscr):
        """Renders the menu with items, search bar, and footer."""
        height, width = stdscr.getmaxyx()
        self._render_search_bar(stdscr, width)
        self._render_items(stdscr, height, width)
        self._render_footer(stdscr, height, width)

    def _render_search_bar(self, stdscr, width):
        """Render the search bar if in search mode."""
        if self.search_mode:
            stdscr.attron(curses.A_BOLD)
            stdscr.addstr(1, 1, "Filter: ", curses.color_pair(3))  # Title of the search bar
            
            stdscr.addstr(1, len("Filter: ") + 1, f"{self.search_query}", curses.color_pair(3))
    
            if not self.search_query:  
                exit_button = " [Esc: Exit]"
                stdscr.addstr(1, len("Filter: ") + len(self.search_query) + 2, exit_button, curses.color_pair(4))
    
            # Clear the remaining space in the search bar
            stdscr.addstr(1, len("Filter: ") + len(self.search_query) + len(exit_button) + 2 if not self.search_query else width - 1, 
                          " " * (width - len("Filter: ") - len(self.search_query) - (len(exit_button) if not self.search_query else 0) - 1), 
                          curses.color_pair(3))
            stdscr.attroff(curses.A_BOLD)
            
            curses.curs_set(1)  # Show the cursor while in search mode
        
    def _render_footer(self, stdscr, height, width):
        """Render the footer with instructions."""
        footer_text = "↑ up • ↓ down • / filter • Ctrl+S sort • Enter Select • Ctrl+D Delete • Ctrl+Q Quit"
        stdscr.attron(curses.color_pair(5))
        stdscr.addstr(height - 1, 0, footer_text[:width - 1].ljust(width - 1), curses.color_pair(5))
        stdscr.attroff(curses.color_pair(5))

    def _render_items(self, stdscr, height, width):
        """Render the menu items with navigation."""
        max_items = self._max_visible_items(height)
        if not self.filtered_items:
            stdscr.addstr(height // 2, (width - len("No items found.")) // 2, "No items found.", curses.color_pair(3))
            return

        for idx in range(self.offset, min(self.offset + max_items, len(self.filtered_items))):
            self._render_item_box(stdscr, idx, height, width)

    def _render_item_box(self, stdscr, idx, height, width):
        """Render a single item box."""
        item = self.filtered_items[idx]
        y_pos = 3 + (idx - self.offset) * 3
        box_width = width - 4  # Subtract for padding
        color_pair = 1 if idx == self.current_row else 2
        stdscr.attron(curses.color_pair(color_pair))
        stdscr.addstr(y_pos, 2, f"╭{'─' * (box_width - 2)}╮")
        stdscr.addstr(y_pos + 1, 2, f"│ {item.display(box_width - 6):<{box_width - 4}} │")
        stdscr.addstr(y_pos + 2, 2, f"╰{'─' * (box_width - 2)}╯")
        stdscr.attroff(curses.color_pair(color_pair))

    def _max_visible_items(self, height):
        """Calculate maximum visible items based on screen height."""
        return (height - 6) // 3

    def handle_navigation(self, key, height):
        """Handle navigation keys."""
        if key == curses.KEY_DOWN:
            self._move_down(height)
        elif key == curses.KEY_UP:
            self._move_up(height)
        elif key == ord('/'):
            self.search_mode = True
            self.search_query = ""
        elif key == 4:  # Ctrl + D
            return True  # Indicates delete selected

    def _move_down(self, height):
        """Move down in the menu."""
        if self.current_row < len(self.filtered_items) - 1:
            self.current_row += 1
        if self.current_row - self.offset >= self._max_visible_items(height):
            self.offset += 1

    def _move_up(self, height):
        """Move up in the menu."""
        if self.current_row > 0:
            self.current_row -= 1
        if self.current_row < self.offset:
            self.offset -= 1

    def _filter_items(self):
        """Filter items based on the search query."""
        query_lower = self.search_query.lower()
        return [item for item in self.items if query_lower in item.manganame.lower()]

    def toggle_sort(self):
        """Toggle sorting between manga name and site."""
        self.sort_by_site = not self.sort_by_site
        key = (lambda item: item.site) if self.sort_by_site else (lambda item: item.manganame)
        self.filtered_items = sorted(self.items, key=key)
        self.current_row = 0
        self.offset = 0

    def handle_search_mode(self, key):
        """Handle search mode input."""
        if key == 10:  # Enter
            self.search_mode = False
            self.filtered_items = self._filter_items()
            self.current_row = 0
        elif key == 27:  # Escape
            self.search_mode = False
            self.search_query = ""
            self.filtered_items = self._filter_items()
        elif key in [127, curses.KEY_BACKSPACE]:
            self.search_query = self.search_query[:-1]
            self.filtered_items = self._filter_items()
        elif 32 <= key < 256:
            self.search_query += chr(key)
            self.filtered_items = self._filter_items()

    def select_item(self):
        """Select the currently highlighted item."""
        selected_item = self.filtered_items[self.current_row]
        curses.endwin()
        return selected_item

    def delete_item(self, item):
        """Delete the selected item."""
        self.items.remove(item)
        self.filtered_items.remove(item)
        self.save_data()

    def save_data(self):
        """Save the current items to JSON."""
        processor = SpiderDataProcessor()
        processor._save_data(processor.processed_data_path, [item.__dict__ for item in self.items])

class MenuUI:
    """Main UI handler for displaying the menu."""

    def __init__(self, stdscr, menu):
        self.stdscr = stdscr
        self.menu = menu
        self._init_curses()

    def _init_curses(self):
        """Initialize curses settings."""
        curses.start_color()
        curses.init_pair(1, curses.COLOR_BLACK, curses.COLOR_YELLOW)
        curses.init_pair(2, curses.COLOR_CYAN, curses.COLOR_BLACK)
        curses.init_pair(3, curses.COLOR_WHITE, curses.COLOR_BLACK)
        curses.init_pair(4, curses.COLOR_YELLOW, curses.COLOR_BLUE)
        curses.init_pair(5, curses.COLOR_BLACK, curses.COLOR_WHITE)
        curses.init_pair(6, curses.COLOR_BLACK, curses.COLOR_BLUE)
        curses.curs_set(0)

    def display_menu(self):
        """Display the menu and handle interactions."""
        while True:
            self.stdscr.clear()
            height, width = self.stdscr.getmaxyx()
            self.menu.render(self.stdscr)
            key = self.stdscr.getch()

            if self.menu.search_mode:
                self.menu.handle_search_mode(key)
            else:
                delete_selected = self.menu.handle_navigation(key, height)
                if delete_selected:
                    self._confirm_deletion()
                if key == ord('\n'):
                    return self.menu.select_item()
                elif key == 17:  # Ctrl+Q
                    break
                elif key == 19:  # Ctrl+S
                    self.menu.toggle_sort()

            self.stdscr.refresh()

    def _confirm_deletion(self):
        """Confirm the deletion of the selected item."""
        selected_item = self.menu.filtered_items[self.menu.current_row]
        self._display_confirmation(selected_item)

        choice = self.stdscr.getch()

        if choice == ord('y'):
            self.menu.delete_item(selected_item)

    def _display_confirmation(self, selected_item):
        self.stdscr.clear()
        height, width = self.stdscr.getmaxyx()

        messages = [
            "Are you sure you want to delete the following item?",
            f"'{selected_item.display(width - 6)}'",
            "(y)es / (n)o [default: n]"
        ]

        for i, message in enumerate(messages):
            y_pos = (height // 2) - 2 + i * 2
            self.stdscr.addstr(y_pos, (width - len(message)) // 2, message[:width - 1])

        self.stdscr.refresh()
        
def UI(stdscr):
    import time
    # Load menu items
    start_time = time.time()
    items = MenuItem.load_menu_items_from_json()
    load_time = time.time() - start_time  # Calculate load time

    # Create menu
    start_time = time.time()
    menu = Menu(items)
    menu_time = time.time() - start_time  # Calculate menu time

    # Create UI
    start_time = time.time()
    ui = MenuUI(stdscr, menu)
    ui_time = time.time() - start_time  # Calculate UI time

    # Return the display result and times
    return ui.display_menu(), load_time, menu_time, ui_time

# Wrap UI in curses and get the item and times
item, load_time, menu_time, ui_time = curses.wrapper(UI)

# Print the link if item exists
if item:
    link = item.lastchapter
    print(link)

# Print all the operation times
print(f"load_menu_items_from_json took {load_time:.4f} seconds.")
print(f"Menu took {menu_time:.4f} seconds.")
print(f"MenuUI took {ui_time:.4f} seconds.")
print(f"Total time taken: {load_time + menu_time + ui_time:.4f} seconds.")
