from SManga.lib.themes.mangathemesia import MangaThemesiaSpider


class MangaswetSpider(MangaThemesiaSpider):
    name = "MangaSwet"
    base_url = "https://healteer.com/"
