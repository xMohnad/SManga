from SManga.lib.themes.mangathemesia import MangaThemesiaSpider


class MangaproSpider(MangaThemesiaSpider):
    name = "MangaPro"
    base_url = "https://promanga.pro/"
